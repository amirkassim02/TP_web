var json_old_antenne_1 = {
"type": "FeatureCollection",
"name": "old_antenne_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1", "adresse": "cheick moussa", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.116303756758903, 11.562455856631177 ] } },
{ "type": "Feature", "properties": { "id": "2", "adresse": "8 metre", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.111011694143514, 11.56090289932826 ] } },
{ "type": "Feature", "properties": { "id": "3", "adresse": "hodan 2", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.10085604165802, 11.558998738945139 ] } },
{ "type": "Feature", "properties": { "id": "4", "adresse": "hodan 1", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.100424027957231, 11.552056952793087 ] } },
{ "type": "Feature", "properties": { "id": "5", "adresse": "face college hodan 3", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.093721209462132, 11.553378214051611 ] } },
{ "type": "Feature", "properties": { "id": "6", "adresse": "angence farah had", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.089122264495948, 11.552935735070104 ] } },
{ "type": "Feature", "properties": { "id": "7", "adresse": "pk 12", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.084474713451726, 11.561884770686039 ] } },
{ "type": "Feature", "properties": { "id": "8", "adresse": "pk13", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.073314440812723, 11.557629686547841 ] } },
{ "type": "Feature", "properties": { "id": "9", "adresse": "lycée de balbala", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.111033063218287, 11.552781561530356 ] } },
{ "type": "Feature", "properties": { "id": "10", "adresse": "4 arrondissement", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.117107196961683, 11.549290774222458 ] } },
{ "type": "Feature", "properties": { "id": "11", "adresse": "fara ancien de balbala", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.123494009214269, 11.554365120133619 ] } },
{ "type": "Feature", "properties": { "id": "14", "adresse": "barwaqo 1", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.111958591790142, 11.56902790383705 ] } },
{ "type": "Feature", "properties": { "id": "15", "adresse": "hayabley zone tour ousbo", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.100302965442353, 11.565844225236901 ] } },
{ "type": "Feature", "properties": { "id": "17", "adresse": "layabley zone balbala 11", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.097500114931449, 11.571227776715391 ] } },
{ "type": "Feature", "properties": { "id": "18", "adresse": "layabley zone balbala 10", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.094203999140454, 11.561834411323618 ] } },
{ "type": "Feature", "properties": { "id": "12", "adresse": "540log", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.082277090228921, 11.574551929723636 ] } },
{ "type": "Feature", "properties": { "id": "13", "adresse": "cite nasib", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.076956530601841, 11.538846067963391 ] } },
{ "type": "Feature", "properties": { "id": "16", "adresse": "zone free PK20", "zone tonpo": null, "ETAT": null }, "geometry": { "type": "Point", "coordinates": [ 43.005988149914565, 11.554823964540109 ] } }
]
}
